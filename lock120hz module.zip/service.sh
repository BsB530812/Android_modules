#!/system/bin/sh
# Lock 120Hz Refresh Rate - service script
# 在 late_start service 阶段执行(system_server 已起,settings 可用)

MODDIR=${0%/*}

# 等待开机完成 + settings provider 就绪,最多 60 秒
for i in $(seq 1 60); do
    if [ "$(getprop sys.boot_completed)" = "1" ]; then
        if settings get system peak_refresh_rate >/dev/null 2>&1; then
            break
        fi
    fi
    sleep 1
done

# 留出余量,避开开机后续的刷新率初始化覆盖
sleep 5

apply_rr() {
    settings put secure miui_refresh_rate 2
    settings put system peak_refresh_rate 120.0
    settings put system min_refresh_rate 120.0
}

# 写入 + 延迟补写,压住可能的二次覆盖
apply_rr
sleep 10
apply_rr
sleep 20
apply_rr
