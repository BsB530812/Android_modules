#!/system/bin/sh
# customize.sh - 安装时执行

ui_print "- 安装 Lock 120Hz Refresh Rate 模块"
ui_print "- 开机将自动锁定刷新率为 120Hz"
ui_print "- 适用于小米 HyperOS LTPO 机型"

# 确保脚本可执行
set_perm_recursive "$MODPATH" 0 0 0755 0755

ui_print "- 安装完成,重启后生效"
